package com.motionfps.personal

import android.app.Activity
import android.app.ActivityManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 14, 20)
    private val panel = Color.rgb(20, 28, 38)
    private val accent = Color.rgb(35, 220, 160)
    private val muted = Color.rgb(155, 170, 185)
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var battery: TextView
    private lateinit var thermal: TextView
    private lateinit var memory: TextView
    private lateinit var network: TextView
    private lateinit var codm: TextView
    private lateinit var profileLabel: TextView
    private var selectedProfile = "Balanced"
    private val codmPackages = listOf(
        "com.activision.callofduty.shooter",
        "com.garena.game.codm",
        "com.tencent.tmgp.kr.codm"
    )

    private val refreshTask = object : Runnable {
        override fun run() {
            refreshMetrics()
            handler.postDelayed(this, 3000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        refreshMetrics()
    }

    override fun onResume() {
        super.onResume()
        handler.post(refreshTask)
    }

    override fun onPause() {
        handler.removeCallbacks(refreshTask)
        super.onPause()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(24))
        }
        scroll.addView(page)

        page.addView(text("MOTION FPS", 27, accent, true))
        page.addView(text("PERSONAL GAMING MONITOR  •  ANDROID 14", 11, muted, true).also {
            it.setPadding(0, dp(5), 0, dp(20))
        })

        val hero = card()
        hero.addView(text("DEVICE STATUS", 12, muted, true))
        status = text("Monitoring this device", 20, Color.WHITE, true)
        hero.addView(status)
        page.addView(hero)

        page.addView(sectionTitle("LIVE DEVICE METRICS"))
        val metrics = card()
        battery = metric(metrics, "Battery")
        thermal = metric(metrics, "Thermal state")
        memory = metric(metrics, "Memory")
        network = metric(metrics, "Network")
        codm = metric(metrics, "CODM foreground")
        page.addView(metrics)

        page.addView(sectionTitle("PERFORMANCE PROFILE"))
        profileLabel = text("Selected: Balanced", 15, Color.WHITE, true)
        page.addView(profileLabel)
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        listOf("Balanced", "Performance", "Max Performance").forEach { name ->
            val b = Button(this).apply {
                text = when (name) {
                    "Max Performance" -> "MAX"
                    else -> name.uppercase(Locale.ROOT)
                }
                textSize = 10f
                setOnClickListener {
                    selectedProfile = name
                    profileLabel.text = "Selected: $selectedProfile"
                    status.text = "Profile selected — Android system limits still apply"
                }
            }
            row.addView(b, LinearLayout.LayoutParams(0, dp(52), 1f).apply {
                setMargins(dp(3), dp(8), dp(3), dp(8))
            })
        }
        page.addView(row)
        page.addView(text(
            "Profiles in this first build are preference presets only. " +
            "They do not overclock the CPU/GPU, force extra processing power, " +
            "or change CODM. Android controls those system limits.",
            12, muted, false
        ).apply { setPadding(0, dp(8), 0, dp(14)) })

        val permission = Button(this).apply {
            text = "OPEN USAGE ACCESS SETTINGS"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            }
        }
        page.addView(permission)
        page.addView(text(
            "Usage access is optional. Android may restrict app-usage visibility. " +
            "If CODM cannot be identified, the status will say unavailable. " +
            "No account, analytics, or internet service is used by this app.",
            12, muted, false
        ).apply { setPadding(0, dp(12), 0, 0) })

        setContentView(scroll)
    }

    private fun refreshMetrics() {
        val batteryIntent = registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val pct = if (level >= 0 && scale > 0) (level * 100 / scale) else -1
        val tempTenths = batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        battery.text = "Battery: " + if (pct >= 0) "$pct%${if (tempTenths > 0) "  •  ${(tempTenths / 10.0)}°C" else ""}" else "Unavailable"

        thermal.text = "Thermal state: ${thermalDescription()}"
        memory.text = "Memory: ${memoryDescription()}"
        network.text = "Network: ${networkDescription()}"
        codm.text = "CODM foreground: ${codmForegroundDescription()}"
        status.text = "Updated ${SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())}"
    }

    private fun thermalDescription(): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return "Not supported by Android version"
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        return when (pm.currentThermalStatus) {
            PowerManager.THERMAL_STATUS_NONE -> "Normal"
            PowerManager.THERMAL_STATUS_LIGHT -> "Light"
            PowerManager.THERMAL_STATUS_MODERATE -> "Moderate"
            PowerManager.THERMAL_STATUS_SEVERE -> "Severe"
            PowerManager.THERMAL_STATUS_CRITICAL -> "Critical"
            PowerManager.THERMAL_STATUS_EMERGENCY -> "Emergency"
            PowerManager.THERMAL_STATUS_SHUTDOWN -> "Shutdown threshold"
            else -> "Unknown"
        }
    }

    private fun memoryDescription(): String {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        val total = info.totalMem / (1024 * 1024)
        val available = info.availMem / (1024 * 1024)
        return "$available MB available / $total MB total (system-wide)"
    }

    private fun networkDescription(): String {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val active = cm.activeNetwork ?: return "Disconnected"
        val caps = cm.getNetworkCapabilities(active) ?: return "Unavailable"
        return when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi connected"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile data connected"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet connected"
            else -> "Connected"
        }
    }

    private fun codmForegroundDescription(): String {
        if (!hasUsageAccess()) return "Permission needed"
        return try {
            val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val end = System.currentTimeMillis()
            val events = usm.queryEvents(end - 15_000, end)
            val event = android.app.usage.UsageEvents.Event()
            var latestPackage: String? = null
            var latestTime = 0L
            while (events.hasNextEvent()) {
                events.getNextEvent(event)
                if (event.eventType == android.app.usage.UsageEvents.Event.MOVE_TO_FOREGROUND ||
                    (Build.VERSION.SDK_INT >= 29 && event.eventType == android.app.usage.UsageEvents.Event.ACTIVITY_RESUMED)) {
                    if (event.timeStamp >= latestTime) {
                        latestTime = event.timeStamp
                        latestPackage = event.packageName
                    }
                }
            }
            if (latestPackage in codmPackages) "Detected (best effort)" else "Not detected / unavailable"
        } catch (_: Exception) {
            "Unavailable"
        }
    }

    private fun hasUsageAccess(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            appOps.unsafeCheckOpNoThrow("android:get_usage_stats", android.os.Process.myUid(), packageName)
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow("android:get_usage_stats", android.os.Process.myUid(), packageName)
        }
        return mode == android.app.AppOpsManager.MODE_ALLOWED
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        setBackgroundColor(panel)
        val p = LinearLayout.LayoutParams(-1, -2)
        p.setMargins(0, dp(8), 0, dp(8))
        layoutParams = p
    }

    private fun metric(parent: LinearLayout, label: String): TextView {
        val v = text("$label: Reading…", 14, Color.WHITE, false)
        v.setPadding(0, dp(7), 0, dp(7))
        parent.addView(v)
        return v
    }

    private fun sectionTitle(value: String) = text(value, 12, accent, true).apply {
        setPadding(0, dp(20), 0, dp(5))
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
