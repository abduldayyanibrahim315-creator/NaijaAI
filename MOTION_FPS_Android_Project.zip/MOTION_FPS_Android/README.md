# MOTION FPS — personal Android project

This is a native Kotlin Android starter project for personal use.

## Build on a phone using GitHub Actions

The `.github/workflows/build-apk.yml` workflow builds a debug APK in GitHub's cloud when code is pushed to `main` or `master`, or when the workflow is manually started.

1. Create a new GitHub repository and upload the **contents** of this project (including the hidden `.github` folder).
2. Open the repository's **Actions** tab. If GitHub asks, enable workflows.
3. Open **Build MOTION FPS APK** and run it with **Run workflow**, or push a commit to `main`/`master`.
4. When the run completes successfully, open that run and download the `MOTION-FPS-debug-APK` artifact.
5. Extract the downloaded ZIP on your phone. Tap `app-debug.apk` to install it. Android may ask you to allow installs from the browser or file manager you used.

GitHub Actions usage and artifact availability depend on the repository/account's current plan and limits. This workflow does not require a paid app-builder subscription, but it does require a GitHub account and internet access.

## Build locally

Open this folder in Android Studio with JDK 17 and Android SDK 35 installed, then run the `assembleDebug` Gradle task. The project uses Android Gradle Plugin 8.6.1 and Kotlin 2.0.20.

## Current app capabilities

- Native Android dashboard (not a web wrapper).
- Battery percentage and battery temperature when Android exposes them.
- Android thermal status where supported.
- System memory information.
- Network transport information.
- Best-effort Call of Duty: Mobile foreground detection after the user grants Usage Access.
- Three selectable profile labels: Balanced, Performance, and Max Performance.

## Important limitations

- This starter does **not** overclock the CPU/GPU, allocate all device resources to CODM, unlock hidden FPS settings, or guarantee higher FPS or lower ping.
- The profile buttons currently change only the selected label; they do not tune device hardware.
- CODM detection depends on the installed game's package name and Android Usage Access behavior. It may not work on every device/region build.
- The app has not yet been built or tested on the target phone. A successful cloud build confirms compilation, not every device-specific behavior.
